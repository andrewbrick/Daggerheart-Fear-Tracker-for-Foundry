# Daggerheart-Fear-Tracker-for-Foundry
A simple overlay that tracks GM fear tokens for the Daggerheart game system
